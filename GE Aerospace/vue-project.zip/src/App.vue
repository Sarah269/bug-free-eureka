<template>

  <div id="app">
    <h1>Compute Product</h1>
    
    <div class = "row"> 
      
    <!-- Input Fields for Numbers  -->
     <div>
      <form action = "">
        <input type="number" v-model="num1" placeholder="Enter first number" class = "box"/><br>
        <input type="number" v-model="num2" placeholder="Enter second number" class = "box" />
        <!-- Compute button -->
        <br><br>
        <input type="submit" value="Compute" class="btn" v-if="!buttonClicked" @click="computeProduct">

        <!-- Product result displayed after clicking the button -->
      
        <p v-if="buttonClicked">The product is: {{ product }}</p>
        
      </form> </div>
    
    <br>

      <div class = "image">
        <!-- Image Section -->
        <img src="https://cdn.theforage.com/vinternships/companyassets/ay2tsYxaTif7Nt6z7/AA4Bnq2tJHALwE8cg/1680718790218/pexels-photo-14197334.jpeg" alt="Sample Image" height="350"><br>
      </div>
    </div>
  </div>

</template>

  <script>
    export default {
      name: 'App',
      data() {
        return{
        num1: null,
        num2: null,
        product: null,
        buttonClicked: false
        }
      },
      methods: {
        computeProduct() {
          this.product = this.num1 * this.num2;
          this.buttonClicked = true;
        }
      }
    }
  </script>

<style>

p{
  font-size: 1.7rem
}

.row{
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
    align-items: center;
}

.row form{
    flex: 1 1 40rem;
    padding: 2rem 2.5rem;
    box-shadow: 0 .5rem 1.5rem rgba(0,0,0,.1);
    border: .1rem solid rgba(0,0,0,.1);
    background: #fff;
    background-repeat: repeat -y;
    border-radius: .5rem;
}

.row .image{
    flex: 1 1 40rem;
}

.row .image img{
    width: 50%;
    
}

.row form .box{
    padding: 1rem;
    font-size: 1.7rem;
    color: #333;
    text-transform: none;
    border: .1rem solid rgba(0,0,0,.1);
    border-radius: .5rem;
    margin: .7rem 0;
    width: 100%
}


.btn{
    display: inline-block;
    margin-top: 1rem;
    border-radius: 5rem;
    background: #333;
    color: #fff;
    padding: .9rem 3.5rem;
    cursor: pointer;
    font-size: 1.7rem;
}
</style>
